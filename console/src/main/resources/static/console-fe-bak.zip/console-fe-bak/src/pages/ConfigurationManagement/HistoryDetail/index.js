import HistoryDetail from './HistoryDetail';

export default HistoryDetail;
