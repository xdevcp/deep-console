import ServiceDetail from './ServiceDetail';

export default ServiceDetail;
