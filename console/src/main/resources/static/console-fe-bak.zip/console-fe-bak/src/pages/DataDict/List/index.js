/*
 * @Author: deep.ng
 * @Date: 2020-03-14 18:16:48
 */
import DataDictList from './list';

export default DataDictList;
