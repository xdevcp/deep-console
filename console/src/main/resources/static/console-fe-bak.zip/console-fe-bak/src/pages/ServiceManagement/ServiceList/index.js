import ServiceList from './ServiceList';

export default ServiceList;
