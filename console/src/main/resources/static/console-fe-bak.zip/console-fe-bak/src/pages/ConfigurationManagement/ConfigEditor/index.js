import ConfigEditor from './NewConfigEditor';

export default ConfigEditor;
