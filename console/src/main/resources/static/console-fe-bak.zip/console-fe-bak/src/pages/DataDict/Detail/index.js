/*
 * @Author: deep.ng
 * @Date: 2020-03-14 18:46:51
 */
import DataDictDetail from './detail';

export default DataDictDetail;
