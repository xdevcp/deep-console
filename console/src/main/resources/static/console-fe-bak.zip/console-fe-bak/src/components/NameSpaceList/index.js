import NameSpaceList from './NameSpaceList';

export default NameSpaceList;
