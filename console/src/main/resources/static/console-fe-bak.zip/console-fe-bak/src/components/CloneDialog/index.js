import CloneDialog from './CloneDialog';

export default CloneDialog;
