import DiffEditorDialog from './DiffEditorDialog';

export default DiffEditorDialog;
