import NewNameSpace from './NewNameSpace';

export default NewNameSpace;
