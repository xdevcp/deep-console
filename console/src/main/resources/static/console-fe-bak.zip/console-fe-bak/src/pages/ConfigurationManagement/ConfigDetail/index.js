import ConfigDetail from './ConfigDetail';

export default ConfigDetail;
