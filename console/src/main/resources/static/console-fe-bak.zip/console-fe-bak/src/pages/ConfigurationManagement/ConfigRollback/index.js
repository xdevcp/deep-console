import ConfigRollback from './ConfigRollback';

export default ConfigRollback;
