import DeleteDialog from './DeleteDialog';

export default DeleteDialog;
