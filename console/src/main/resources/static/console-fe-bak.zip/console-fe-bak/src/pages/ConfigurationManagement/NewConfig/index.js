import NewConfig from './NewConfig';

export default NewConfig;
