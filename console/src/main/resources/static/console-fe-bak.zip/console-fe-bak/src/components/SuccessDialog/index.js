import SuccessDialog from './SuccessDialog';

export default SuccessDialog;
