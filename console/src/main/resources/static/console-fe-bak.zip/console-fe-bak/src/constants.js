export const LANGUAGE_KEY = 'docsite_language';
export const LANGUAGE_SWITCH = 'LANGUAGE_SWITCH';

// TODO: 后端暂时没有统一成功失败标记
// export const SUCCESS_RESULT_CODE = 'SUCCESS';

export const REDUX_DEVTOOLS = '__REDUX_DEVTOOLS_EXTENSION__';

export const GET_STATE = 'GET_STATE';

export const GET_SUBSCRIBERS = 'GET_SUBSCRIBERS';
export const REMOVE_SUBSCRIBERS = 'REMOVE_SUBSCRIBERS';
