import BatchHandle from './BatchHandle';

export default BatchHandle;
