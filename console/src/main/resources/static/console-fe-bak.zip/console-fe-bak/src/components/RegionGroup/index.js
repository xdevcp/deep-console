import RegionGroup from './RegionGroup';

export default RegionGroup;
