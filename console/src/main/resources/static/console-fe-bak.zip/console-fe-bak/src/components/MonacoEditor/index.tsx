
import MonacoEditor from './MonacoEditor';

export default MonacoEditor;
