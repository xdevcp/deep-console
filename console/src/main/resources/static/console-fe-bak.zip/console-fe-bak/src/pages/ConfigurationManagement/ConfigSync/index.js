import ConfigSync from './ConfigSync';

export default ConfigSync;
