import NameSpace from './NameSpace';

export default NameSpace;
