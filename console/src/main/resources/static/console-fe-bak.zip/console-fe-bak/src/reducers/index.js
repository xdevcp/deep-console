import locale from './locale';
import base from './base';
import subscribers from './subscribers';

export default { locale, base, subscribers };
