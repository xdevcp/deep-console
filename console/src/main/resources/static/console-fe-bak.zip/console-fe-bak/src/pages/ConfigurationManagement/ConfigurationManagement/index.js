import ConfigurationManagement from './ConfigurationManagement';

export default ConfigurationManagement;
