import SubscriberList from './SubscriberList';

export default SubscriberList;
