import ListeningToQuery from './ListeningToQuery';

export default ListeningToQuery;
